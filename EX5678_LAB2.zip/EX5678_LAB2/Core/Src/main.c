/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Tick ​​of TIM2 (unit ms). Set to the actual period of the timer.
#define TICK_MS              2        // TIM2 interrupt each 2 ms
// Time each digit lights up (ms). 2 ms/digit => 8 ms/frame (4 digits) ~125 Hz, no flicker.
#define SCAN_MS_PER_DIGIT    2
// Number of ticks to move digit (>=1)
#define STEP_EVERY_TICKS     (((SCAN_MS_PER_DIGIT) + (TICK_MS) - 1) / (TICK_MS))
// Number of ticks to flash DOT every 1 second
#define DOT_EVERY_TICKS      (1000 / (TICK_MS))

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
const int MAX_LED = 4;          // 4 digits: H_tens, H_ones, M_tens, M_ones
int index_led = 0;              // 0..3
int led_buffer[4] = {1,2,3,4};  // will be load by updateClockBuffer()
uint32_t dot_tick = 0;
int hour = 15, minute = 8, second = 50;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#include <stdbool.h>

//bit0=a, bit1=b, ... bit6=g
static const uint8_t segCode[10] = {
		  /*0*/ 0b1000000,  // abcdef ON, g OFF
		  /*1*/ 0b1111001,  // b c
		  /*2*/ 0b0100100,  // a b d e g
		  /*3*/ 0b0110000,  // a b c d g
		  /*4*/ 0b0011001,  // b c f g
		  /*5*/ 0b0010010,  // a c d f g
		  /*6*/ 0b0000010,  // a c d e f g
		  /*7*/ 0b1111000,  // a b c
		  /*8*/ 0b0000000,  // all
		  /*9*/ 0b0010000   // a b c d f g
};
// Mapping GPIO Pins a..g to PBx pins in Proteus.
// a->PB0, b->PB1, ..., g->PB6 in CubeIDE GPIO Pins Configure
static const uint16_t segPins[7] = {
  GPIO_PIN_0, // a -> PB0
  GPIO_PIN_1, // b -> PB1
  GPIO_PIN_2, // c -> PB2
  GPIO_PIN_3, // d -> PB3
  GPIO_PIN_4, // e -> PB4
  GPIO_PIN_5, // f -> PB5
  GPIO_PIN_6  // g -> PB6
};

// 0-9 numbers on 7-seg COM-ANODE (0=ON, 1=OFF)
void display7SEG(uint8_t num)
{
  if (num > 9) return;
  uint8_t code = segCode[num];

  for (int i = 0; i < 7; ++i) {
    /* bit = 1 (OFF) -> SET (HIGH); bit = 0 (ON) -> RESET (LOW) */
    GPIO_PinState st = (code & (1U << i)) ? GPIO_PIN_SET : GPIO_PIN_RESET;
    HAL_GPIO_WritePin(GPIOB, segPins[i], st);
  }
}



void update7SEG(int index) {
    // Turn OFF all EN
    HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, GPIO_PIN_SET);

    switch(index) {
        case 0:
            display7SEG(led_buffer[0]);     // Display number on LED1
            HAL_GPIO_WritePin(GPIOA, EN0_Pin, GPIO_PIN_RESET);
            break;
        case 1:
            display7SEG(led_buffer[1]);     // Display number on LED2
            HAL_GPIO_WritePin(GPIOA, EN1_Pin, GPIO_PIN_RESET);
            break;
        case 2:
            display7SEG(led_buffer[2]);     // Display number on LED3
            HAL_GPIO_WritePin(GPIOA, EN2_Pin, GPIO_PIN_RESET);
            break;
        case 3:
            display7SEG(led_buffer[3]);     // Display number on LED4
            HAL_GPIO_WritePin(GPIOA, EN3_Pin, GPIO_PIN_RESET);
            break;
        default:
            break;
    }
}


// Load hour:minute -> [H_tens, H_ones, M_tens, M_ones] (zero-padding)
void updateClockBuffer(int hour, int minute) {
    int h_tens = hour / 10;    // Tens place of hour
    int h_ones = hour % 10;    // Ones place of hour
    int m_tens = minute / 10;  // Tens place of minute
    int m_ones = minute % 10;  // Ones place of minute

    led_buffer[0] = h_tens;    // Store hour tens in led_buffer[0]
    led_buffer[1] = h_ones;    // Store hour ones in led_buffer[1]
    led_buffer[2] = m_tens;    // Store minute tens in led_buffer[2]
    led_buffer[3] = m_ones;    // Store minute ones in led_buffer[3]
}

int timer0_counter = 0;  // Counter for the timer
int timer0_flag = 0;     // Flag to indicate when the timer has finished
int TIMER_CYCLE = 10;    // Timer cycle, 10ms

// Function to set the timer with a given duration in ms
void setTimer0(int duration) {
    timer0_counter = duration / TIMER_CYCLE; // Calculate the number of timer cycles needed
    timer0_flag = 0;  // Reset the flag
}

// Function to decrement the timer counter every 10ms
void timer_run() {
    if (timer0_counter > 0) {
        timer0_counter--;  // Decrease the counter
    }
    if (timer0_counter == 0) {
        timer0_flag = 1;  // Set the flag when the timer is done
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  // Default: OFF=SET: DOT OFF, ENx OFF
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|
                           GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6,
                           GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOA, DOT_Pin, GPIO_PIN_SET); //Turn ON LED_DOT: COM-ANODE, RESET=0 ->ON
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, GPIO_PIN_SET);

  // Initialize 4 digits (1, 2, 3, 4)
  led_buffer[0] = 1;
  led_buffer[1] = 2;
  led_buffer[2] = 3;
  led_buffer[3] = 4;

  updateClockBuffer(hour, minute);
  HAL_TIM_Base_Start_IT(&htim2);

  setTimer0(1000);  // Set a 1000ms (1 second) timer
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

      // Check if the timer has elapsed (after 1000ms)
      if (timer0_flag == 1) {
          timer0_flag = 0;  // Reset the flag
          update7SEG(index_led);  // Update the 7-segment display
          index_led++;

          if (index_led >= MAX_LED) {
              index_led = 0;  // Reset to the first LED if we've reached the last
          }

          setTimer0(1000);  // Reset the timer for 1000ms (1 second)
      }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 2; //0..1 -> 2 counts -> 2ms
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DOT_Pin|LED_Pin|EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, A_Pin|B_Pin|C_Pin|D_Pin
                          |E_Pin|F_Pin|G_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DOT_Pin LED_Pin EN0_Pin EN1_Pin
                           EN2_Pin EN3_Pin */
  GPIO_InitStruct.Pin = DOT_Pin|LED_Pin|EN0_Pin|EN1_Pin
                          |EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : A_Pin B_Pin C_Pin D_Pin
                           E_Pin F_Pin G_Pin */
  GPIO_InitStruct.Pin = A_Pin|B_Pin|C_Pin|D_Pin
                          |E_Pin|F_Pin|G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM2) {
        timer_run();  // Handle software timer in the interrupt
    }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
